import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { PaymentCard } from '@/components/property/payment-card';
import { ReviewForm } from '@/components/property/review-form';
import { StatusBadge } from '@/components/dashboard/status-badge';
import { CalendarDays, MapPin, Users, Building2, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import Link from 'next/link';

export const revalidate = 0;

export default async function MesReservationsPage({
  searchParams,
}: {
  searchParams: { booking_sent?: string; payment_sent?: string; review_sent?: string; error?: string };
}) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/connexion?redirect=/mes-reservations');
  }

  const { data: bookings } = await supabase
    .from('bookings')
    .select(`
      id, check_in, check_out, guests, total_price, status, payment_confirmed_by_client, created_at, rejection_reason,
      properties!inner (
        id, title, quartier, type, price_per_night,
        property_images ( url, position ),
        profiles!properties_host_id_fkey ( full_name, phone, mobile_money_number )
      )
    `)
    .eq('client_id', user.id)
    .order('created_at', { ascending: false });

  const { data: userReviews } = await supabase
    .from('reviews')
    .select('booking_id')
    .eq('author_id', user.id);

  const reviewedBookingIds = new Set((userReviews || []).map((r) => r.booking_id).filter(Boolean));

  return (
    <>
      <Navbar />
      <main className="bg-warm min-h-screen pt-28 pb-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-navy">Mes réservations</h1>
            <p className="text-navy/60 text-sm mt-1">
              Retrouvez l'historique et l'état de vos demandes de séjour.
            </p>
          </div>

          {/* Messages d'alerte */}
          {searchParams.booking_sent && (
            <div className="mb-6 rounded-2xl bg-emerald-50 border border-emerald-200 p-4 text-emerald-800 text-sm flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <strong className="font-bold">Demande envoyée avec succès !</strong>
                <p className="text-emerald-700 text-xs">L'hôte répondra sous 24h. Vous recevrez des indications pour le paiement dès qu'elle est acceptée.</p>
              </div>
            </div>
          )}

          {searchParams.payment_sent && (
            <div className="mb-6 rounded-2xl bg-amber-50 border border-amber-200 p-4 text-amber-800 text-sm flex items-center gap-3">
              <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <strong className="font-bold">Paiement signalé à l'hôte !</strong>
                <p className="text-amber-700 text-xs">L'hôte va vérifier la réception de votre virement Mobile Money et valider la réservation.</p>
              </div>
            </div>
          )}

          {searchParams.error && (
            <div className="mb-6 rounded-2xl bg-red-50 border border-red-200 p-4 text-red-700 text-sm flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{searchParams.error}</span>
            </div>
          )}

          {/* Liste des réservations */}
          {!bookings || bookings.length === 0 ? (
            <div className="rounded-3xl bg-white p-12 text-center shadow-sm border border-navy/5 space-y-4">
              <div className="w-16 h-16 rounded-full bg-sun/10 flex items-center justify-center mx-auto text-sun">
                <Building2 className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl font-bold text-navy">Aucune réservation pour le moment</h3>
              <p className="text-navy/60 text-sm max-w-md mx-auto">
                Vous n'avez pas encore effectue de demande de logement à Kribi. Découvrez nos annonces et réservez votre séjour.
              </p>
              <Link
                href="/#sejours"
                className="inline-flex items-center justify-center bg-sun text-white font-semibold rounded-full px-6 py-3 hover:bg-sun/90 transition text-sm shadow-md shadow-sun/30"
              >
                Explorer les logements
              </Link>
            </div>
          ) : (
            <div className="space-y-6">
              {bookings.map((b: any) => {
                const prop = b.properties;
                const images = [...(prop?.property_images || [])].sort((a: any, b: any) => a.position - b.position);
                const thumb = images[0]?.url || '/placeholder.jpg';
                const host = prop?.profiles;

                return (
                  <div
                    key={b.id}
                    className="rounded-3xl bg-white border border-navy/10 p-6 shadow-sm hover:shadow-md transition space-y-6"
                  >
                    {/* Header logement & statut */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-navy/5">
                      <div className="flex items-center gap-4">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={thumb}
                          alt={prop?.title}
                          className="w-16 h-16 rounded-2xl object-cover shrink-0 bg-navy/5"
                        />
                        <div>
                          <Link href={`/${prop?.id}`} className="font-display font-bold text-lg text-navy hover:text-sun transition line-clamp-1">
                            {prop?.title}
                          </Link>
                          <div className="flex items-center gap-3 text-xs text-navy/60 mt-0.5">
                            <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{prop?.quartier}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{b.guests} pers.</span>
                          </div>
                        </div>
                      </div>
                      <StatusBadge status={b.status} />
                    </div>

                    {/* Informations dates et prix */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm bg-navy/5 p-4 rounded-2xl">
                      <div>
                        <span className="text-xs text-navy/50 block font-medium uppercase tracking-wider">Arrivée</span>
                        <span className="font-semibold text-navy flex items-center gap-1.5 mt-0.5">
                          <CalendarDays className="w-4 h-4 text-sun" />
                          {formatDate(b.check_in)}
                        </span>
                      </div>
                      <div>
                        <span className="text-xs text-navy/50 block font-medium uppercase tracking-wider">Départ</span>
                        <span className="font-semibold text-navy flex items-center gap-1.5 mt-0.5">
                          <CalendarDays className="w-4 h-4 text-sun" />
                          {formatDate(b.check_out)}
                        </span>
                      </div>
                      <div className="col-span-2 sm:col-span-1">
                        <span className="text-xs text-navy/50 block font-medium uppercase tracking-wider">Prix Total</span>
                        <span className="font-display font-bold text-navy text-base mt-0.5 block">
                          {b.total_price?.toLocaleString('fr-FR')} FCFA
                        </span>
                      </div>
                    </div>

                    {/* Statut spécifique / Action paiement */}
                    {b.status === 'pending' && (
                      <div className="flex items-center gap-3 rounded-2xl bg-amber-50 border border-amber-100 p-4 text-amber-800 text-sm">
                        <Clock className="w-5 h-5 text-amber-500 shrink-0" />
                        <div>
                          <p className="font-bold">Demande en attente de réponse</p>
                          <p className="text-amber-700 text-xs mt-0.5">
                            L'hôte ({host?.full_name || 'Hôte'}) examine votre demande. Vous recevrez la confirmation et le numéro Mobile Money dès qu'elle est acceptée.
                          </p>
                        </div>
                      </div>
                    )}

                    {b.status === 'rejected' && (
                      <div className="flex items-center gap-3 rounded-2xl bg-red-50 border border-red-100 p-4 text-red-800 text-sm">
                        <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
                        <div>
                          <p className="font-bold">Demande refusée</p>
                          <p className="text-red-700 text-xs mt-0.5">
                            {b.rejection_reason || "L'hôte ne peut pas vous accueillir pour ces dates."}
                          </p>
                        </div>
                      </div>
                    )}

                    {(b.status === 'accepted' || b.status === 'completed') && (
                      <PaymentCard
                        bookingId={b.id}
                        totalPrice={b.total_price}
                        mobileMoneyNumber={host?.mobile_money_number}
                        hostName={host?.full_name}
                        paymentConfirmedByClient={b.payment_confirmed_by_client}
                        isCompleted={b.status === 'completed'}
                      />
                    )}

                    {b.status === 'completed' && (
                      <div className="pt-3 border-t border-navy/5">
                        {reviewedBookingIds.has(b.id) ? (
                          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-full">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Avis déposé</span>
                          </div>
                        ) : (
                          <ReviewForm
                            bookingId={b.id}
                            propertyId={prop?.id}
                            targetType="property"
                            title={prop?.title}
                          />
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}

function formatDate(d: string) {
  if (!d) return '-';
  return new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
}
