export const PROPERTY_TYPE_OPTIONS = [
    { value: 'chambre', label: 'Chambre' },
    { value: 'appartement_studio', label: 'Appartement & studio' },
    { value: 'maison', label: 'Maison' },
    { value: 'villa', label: 'Villa' },
    { value: 'autre', label: 'Autre' },
] as const;

export const PROPERTY_TYPE_LABELS: Record<string, string> = Object.fromEntries(
    PROPERTY_TYPE_OPTIONS.map(({ value, label }) => [value, label])
);

// Image utilisée tant qu'un hôte n'a pas encore ajouté de photo à son logement.
export const FALLBACK_PROPERTY_IMAGE =
    'https://images.pexels.com/photos/23384204/pexels-photo-23384204.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop';